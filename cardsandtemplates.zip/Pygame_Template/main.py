# Pygame template - skeleton for a new pygame project
from Player import *
import random
import pygame

WIDTH = 360
HEIGHT = 480
FPS = 30

# define colors, colors work in a (RGB) format. remember the diodes
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
SOFT_GRAY = (10,10,10)

# initialize pygame and create window
pygame.init()
pygame.mixer.init()      #This is initialized for the purposes of sound
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("My Game")
clock = pygame.time.Clock() #Creates time

class Player(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((50,50)) #dimensions of player, aka creating the image origionally
        self.image.fill(GREEN) #Color of player, fill bucket
        self.rect = self.image.get_rect() #rect means rectangle. NO SQUARES, JUSTICE FOR SQUARES
        self.rect.center = (WIDTH / 2, HEIGHT / 2)

    def movement_direction(self,min,max):
        movement = 0
        if self.rect.left > max:
            movement = 5
            return movement
        elif self.rect.right < min:
            movement = -5
            return movement
        else:
            return 5




    def update(self):
        direction = self.movement_direction(20, 200)
        self.rect.x += 5
        if self.rect.left > WIDTH: #If the left side of the sprite leaves the screen
            self.rect.right = 0 #wrap it to the right
        elif self.rect.right < 0:
            self.rect.left = WIDTH


all_sprites = pygame.sprite.Group()
player = Player()
all_sprites.add(player)


# Game loop
running = True
while running:
    # keep loop running at the right speed
    clock.tick(FPS)
    # Process input (events)
    for event in pygame.event.get(): #each action/button press. If the X is pressed, continue below
        # check for closing window
        if event.type == pygame.QUIT:
            running = False

    # Update
    all_sprites.update() #updates the sprites value


    # Draw / render
    screen.fill(SOFT_GRAY)
    all_sprites.draw(screen) #draws the sprites on the screen


    # *after* drawing everything, flip the display. Think whiteboard
    pygame.display.flip()








pygame.quit()
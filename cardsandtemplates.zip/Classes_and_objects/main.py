# Tyler Johnson
# Classes and objects
# 1/17/2023

import person


tyler = person.Person("Tyler",True,True,False,"Blue","M",75,170,17,"B","Blond","Owner")
kaine = person.Person("Kaine",True,False,False,"Brown","M",72,145,16,"O+","Rainbow","Yes")
landon = person.Person("Landon")

print(tyler)
print(kaine)
print(landon)
landon.speak("Hi My name is "+landon.name)
landon.die()
print("Is landon alive? "+str(landon.isAlive))
print(person.Person.people_count)


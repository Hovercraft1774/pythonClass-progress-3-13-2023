import person

class Tyler(person.Person):

    def __init__(self):
        super(Tyler, self).__init__()
        self.weight = 170
        self.isAlive = True
        self.language = person.Person.languages[0]
        self.happy = True
        self.mad = False
        self.bloodType = "B"
        self.eyeColor = "blue"
        self.height = 75
        self.gender = "male"
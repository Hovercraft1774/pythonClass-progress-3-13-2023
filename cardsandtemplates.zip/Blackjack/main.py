# Tyler Johnson
# 1/19/2023
# Black Jack
import random
from commonGameFunctions import *
from BlackJack_Classes import *
from cards_file import *
from player_file import *

def main():
    print("\t\tWelcome to Blackjack!\n")
    names = []
    players = ask_number("How many Players are there? (Maximum of 7)", 1, 7)
    for i in range(players):
        player = input("Player "+str(i+1)+", Please Enter Your Name \t")
        names.append(player)
    game = BlackJack_Game(names)
    play = None
    while play != "n":
        game.play()
        play = ask_yes_no("Would you like to play again?")



main()



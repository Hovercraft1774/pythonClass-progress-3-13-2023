from player_file import *
from commonGameFunctions import *



def main():
    deck = Base_Deck()
    pop = Base_Deck.populate
    shuf = Base_Deck.shuffle
    print(deck)
    print(pop)
    print(shuf)


main()










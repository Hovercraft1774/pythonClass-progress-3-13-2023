from scripts.settings import *
from scripts.player import *
from scripts.enemy import *
from scripts.explosions import *

def draw_Text(screen,text,size,x,y,color):
    font_name = pg.font.match_font("comic_sans")
    font = pg.font.Font(font_name,size)
    text_sprite = font.render(text,True,color)
    text_rect = text_sprite.get_rect()
    text_rect.midtop = (x,y)
    screen.blit(text_sprite,text_rect)

class Game(object):

    def __init__(self):
        self.playing = True
        pg.init()
        pg.mixer.init() #if using online editor, take this out
        # creates a screen for the game
        self.screen = pg.display.set_mode((WIDTH,HEIGHT))
        pg.display.set_caption(TITLE) #Title of the screen window
        # creates time
        self.clock = pg.time.Clock()
        self.mod_img = []
        self.explosion_animation = {}
        self.explosion_animation["L"] = []
        self.explosion_animation["S"] = []

        # create Sprite Groups
        self.all_sprites = pg.sprite.Group()
        self.enemy_group = pg.sprite.Group()
        self.player_group = pg.sprite.Group()
        self.bullet_group = pg.sprite.Group()
        self.powerup_group = pg.sprite.Group()
        self.defaultColor = DEFAULT_COLOR

        self.debugging = debugging
        self.totalScore = 0
        self.maxAsteroids = 25
        self.timeSecond = 0


        #create player player objects
        self.load_imgs()
        self.player = Player(self,WIDTH/4,HEIGHT-50,random.choice(playerShips),self.defaultColor)

    def load_imgs(self):
    #background
        self.bg_img = pg.image.load(os.path.join(background_folder,bg_img)).convert()
        self.bg_img = pg.transform.scale(self.bg_img,(WIDTH,HEIGHT))

    #enemies


    #player
        self.player_img = pg.image.load(random.choice(playerShips))
        self.player_img = pg.transform.scale(self.player_img,(player_w,player_h))
        self.bullet_img = pg.image.load(player_bullet)
        self.bullet_img = pg.transform.scale(self.bullet_img,(bullet_w,bullet_h))

        #explosions
        for i in range(9):
            filename = str.format("Missile_2_Explosion_00{}.png", i)
            img = pg.image.load(os.path.join(explosions_folder,filename)).convert()
            img.set_colorkey(self.defaultColor)
            img_l = pg.transform.scale(img,(75,75))
            img_s = pg.transform.scale(img,(25,25))
            self.explosion_animation["L"].append(img_l)
            self.explosion_animation["L"].append(img_s)



        #create enemy objects
    def spawnEnemies(self):
        for i in range(self.maxAsteroids - len(self.enemy_group)):
            self.mob = Mob(self, random.choice(meteors), self.defaultColor)


    def getSecond(self,second):
        if self.timeSecond == fps//second:
            self.timeSecond = 0
            return True
        else:
            return False

    def gameLoop(self):
        while self.playing:
            #tick clock
            self.clock.tick(fps)

            #check events
            self.check_Events()

            #update all
            self.update()

            #draw
            self.draw()



    def check_Events(self):
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()


            if event.type == pg.KEYDOWN:
                if event.key == pg.K_m: #initiate mouse movement/cancel it
                    self.player.mouseMovement = not self.player.mouseMovement




        if self.maxAsteroids > len(self.enemy_group):
            self.spawnEnemies()




        #if single sprite hit anything in blank group, kill group object?
        # hits = pg.sprite.spritecollide(self.player,self.enemy_group,False)
        #if group hit group, kill group1 or 2
        hits = pg.sprite.spritecollide(self.player, self.enemy_group, False,pg.sprite.collide_circle)  # checks for player sprite collision
        if hits:  # ends game if hit
            self.playing = False
        hits = pg.sprite.groupcollide(self.enemy_group, self.bullet_group, True,True)  # check for collision between bullets and mobs

        if hits:
            for hit in hits:
            #explosion for asteroids
                exp = Explosion(self, hit.rect.center, "L")
            # check/spawn powerup
                z = random.randint(0,20)
                # z = 69
                if z == 0:
                    self.powerup = Powerup(self,hit.rect.centerx,hit.rect.centery,fast_Fire,self.defaultColor)





        if self.player.mouseMovement == True:
            pg.mouse.set_visible(False)
        else:
            pg.mouse.set_visible(True)




    def update(self):
        self.all_sprites.update()
        self.timeSecond += 1
        self.totalScore += 1





    def draw(self):
        self.screen.fill(BLACK)
        self.screen.blit(self.bg_img,self.bg_img.get_rect())
        self.all_sprites.draw(self.screen)
        # self.background.blit(self.screen)
        draw_Text(self.screen,str(self.totalScore),30,WIDTH/2,15,WHITE)




        # think whiteboard, must be last line
        pg.display.flip()

    def start_Screen(self):
        pass
    def end_Screen(self):
        pass
from scripts.settings import *


class Player(pg.sprite.Sprite):#must be a sprite inherited otherwise it won't fit in groups

    def __init__(self,game,x,y,img,color_key):
        super(Player,self).__init__()

        # self.image = pg.image
        # self.image.load(self.image)
        self.color_key = color_key
        self.image = self.get_image(img)
        self.image.set_colorkey(self.color_key)#gets rid of black color and makes it transparent
        self.rect = self.image.get_rect()
        self.game = game #adds reference to the game
        self.radius = player_w*0.85//2

        # self.image = pg.Surface((50,50)) #creates and makes this thing a rectangle
        # self.image.fill(color)
        # self.rect = self.image.get_rect()
        self.speed = playerSpeed
        self.health = 100

        if debugging:
            pg.draw.circle(self.image,WHITE,self.rect.center,self.radius,2)

        self.rect.center = (x,y)
        self.mouseMovement = False
        self.xMove = 0
        self.solidbounds = solidbounds
        self.addToGroups()
        self.canShoot = True



    def addToGroups(self):
        self.game.all_sprites.add(self)
        self.game.player_group.add(self)

    def get_image(self,img_dir):
        self.img = pg.image.load(img_dir).convert()
        self.img = pg.transform.scale(self.img, (player_w, player_h))
        return self.img


    def setMoveX(self,speed):
        if self.solidbounds:
            if self.rect.right >= WIDTH:
                self.rect.right = WIDTH
            if self.rect.bottom >= HEIGHT:
                self.rect.bottom = HEIGHT

            if self.rect.left <= 0:
                self.rect.left = 0

            if self.rect.top <= 0:
                self.rect.top = 0
        else:
            if self.rect.left > WIDTH:
                self.rect.right = 0
            if self.rect.top > HEIGHT:
                self.rect.bottom = 0

            if self.rect.right < 0:
                self.rect.left = WIDTH

            if self.rect.bottom < 0:
                self.rect.top = HEIGHT

        self.rect.x += speed
    def shoot(self):
        Bullet(self.game, self.rect.centerx, self.rect.top-2,player_bullet,self.color_key)


    def update(self):
        self.xMove = 0
        # if self.mouseMovement == True:
        #     #make the character follow mouse
        #     self.rect.center = pg.mouse.get_pos()
        #     self.leftClick = pg.mouse.get_pressed()[0]
        keys = pg.key.get_pressed()
        if keys[pg.K_a or pg.K_LEFT]:  # if key is being pressed, move left
            self.setMoveX(-self.speed)
        if keys[pg.K_d or pg.K_RIGHT]:  # if key is being pressed, move right
            self.setMoveX(self.speed)
        if keys[pg.K_SPACE]:
            if self.canShoot:
                self.canShoot = False
                self.shoot()

        if self.game.getSecond(4):
            self.canShoot = True
















        self.game.check_Events()
        #temporary auto move


class Bullet(pg.sprite.Sprite):
    def __init__(self,game,x,y,img,color_key):
        super(Bullet, self).__init__()

        # self.image = self.get_image(img_dir)
        # self.image.set_colorkey(color_key)  # gets rid of black color and makes it transparent
        # self.rect = self.image.get_rect()
        self.game = game  # adds reference to the game
        # self.image = pg.Surface((5,25)) #creates and makes this thing a rectangle
        # self.image.fill(BLUE)
        self.image = self.get_image(img)
        self.image.set_colorkey(color_key)#gets rid of black color and makes it transparent
        self.rect = self.image.get_rect()
        self.rect.bottom = y
        self.rect.centerx = x
        self.move_y = -10
        self.addToGroups()

    def addToGroups(self):
        self.game.all_sprites.add(self)
        self.game.bullet_group.add(self)

    def update(self):
        self.rect.centery += self.move_y
        if self.rect.bottom < 0:
            self.kill()


    def get_image(self,img_dir):
        self.img = pg.image.load(img_dir).convert()
        self.img = pg.transform.scale(self.img, (bullet_w, bullet_h))
        return self.img


class Powerup(pg.sprite.Sprite):
    def __init__(self,game,x,y,img,color_key):
        super(Powerup, self).__init__()

        # self.image = self.get_image(img_dir)
        # self.image.set_colorkey(color_key)  # gets rid of black color and makes it transparent
        # self.rect = self.image.get_rect()
        self.game = game  # adds reference to the game
        # self.image = pg.Surface((5,25)) #creates and makes this thing a rectangle
        # self.image.fill(BLUE)
        self.image = self.get_image(img)
        self.image.set_colorkey(color_key)  # gets rid of black color and makes it transparent
        self.rect = self.image.get_rect()
        self.rect.bottom = y
        self.rect.centerx = x
        self.move_y = 10
        self.addToGroups()

    def addToGroups(self):
        self.game.all_sprites.add(self)
        self.game.powerup_group.add(self)

    def update(self):
        self.rect.centery += self.move_y
        if self.rect.bottom < 0:
            self.kill()

    def get_image(self, img_dir):
        self.img = pg.image.load(img_dir).convert()
        self.img = pg.transform.scale(self.img, (bullet_w, bullet_h))
        return self.img

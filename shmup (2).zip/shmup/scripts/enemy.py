from scripts.settings import *
from scripts.player import *


class Mob(pg.sprite.Sprite):
    def __init__(self,game,img_dir,color_key):
        super(Mob,self).__init__()
        self.game = game

        #this makes just a basic rectangle
        # self.image = pg.Surface((50,50))
        # self.image.fill(RED)
        self.color_key = color_key
        self.size = random.randint(30,130)
        self.image_origional = img_dir
        self.image = self.get_image(self.image_origional).copy()
        self.rect = self.image.get_rect()
        self.radius = self.size*0.85//2

    #checks hitboxes
        if debugging:
            pg.draw.circle(self.image,WHITE,self.rect.center,self.radius,2)




        self.reset()
        self.addToGroups()

    def addToGroups(self):
        self.game.all_sprites.add(self)
        self.game.enemy_group.add(self)


    def get_image(self,img_dir):
        self.img = pg.image.load(img_dir).convert()
        self.img = pg.transform.scale(self.img, (self.size,self.size))
        self.img.set_colorkey(self.color_key)#gaets rid of black color and makes it transparent
        return self.img

    def update(self):
        self.rect.centerx += self.move_x
        self.rect.centery += self.move_y

        if self.rect.y > HEIGHT+100:
            self.reset()
        if self.rect.left > WIDTH +50 or self.rect.right <0-50:
            self.reset()
        self.rotate()

    def reset(self):
        self.rect.center = (random.randint(0+self.rect.width,WIDTH-self.rect.width),random.randint(-200,-40))
        self.move_x = random.randint(-250//self.size, 250//self.size)
        self.move_y = random.randint(400//self.size, 400//self.size)
        self.rot = 0
        self.rot_speed = random.randint(-8,8)
        self.last_update = pg.time.get_ticks() #gets the time from the last rotate

    def rotate(self):
        now = pg.time.get_ticks()
        if now - self.last_update > fps: #if a second has passed
            self.last_update = now
            self.rot = (self.rot + self.rot_speed)%360
            # new_image = pg.transform.rotate(self.get_image(self.image_origional).copy(),self.rot)
            old_center = self.rect.center
            # self.image = new_image
            self.rect = self.image.get_rect()
            self.rect.center = old_center







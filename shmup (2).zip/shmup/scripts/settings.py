import os.path

import pygame as pg
import random


# define colors, colors work in a (RGB) format.
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255,255,0)
TEAL = (0,255,255)
PINK = (255,0,255)
ORANGE = (255,127,0)
DARK_GRAY = (64,64,64)
LIGHT_GRAY = (192,192,192)
GRAY_BLUE = (92,192,194)

colors = (WHITE,BLUE,BLACK,RED,GREEN,YELLOW,TEAL,PINK,ORANGE)



#Game Title
TITLE = "Galatic JoyRide"



# Window Settings
WIDTH = 750
HEIGHT = 1000
DEFAULT_COLOR = BLACK
TILE_SIZEX = WIDTH/15
TILE_SIZEY = HEIGHT/15
debugging = False


# camera settings
fps = 40




# file locations
#gets location of file on computer
game_folder = os.path.dirname(__file__)
game_folder = game_folder.replace("\scripts","")
sprites_folder = os.path.join(game_folder,"sprites")
player_folder = os.path.join(sprites_folder,"playerSprites")
enemy_folder = os.path.join(sprites_folder,"enemySprites")
background_folder = os.path.join(sprites_folder,"backgrounds")
explosions_folder = os.path.join(background_folder,"explosions")
ammo_folder = os.path.join(player_folder,"ammo")
powerups_folder = os.path.join(player_folder,"powerups")


#backgrounds

bg_images = ["Map_01_1080x3000.png","Map_02_1080x3000.png","Map_04_1080x3000.png","Space_BG_01.png","Space_BG_02.png","Space_BG_03.png","Space_BG_04.png"]

bg_img = os.path.join(background_folder,random.choice(bg_images))




# player Settings
solidbounds = True

player_fire_rate = 4
playerSpeed = 12
player_w = 65
player_h = 65
bullet_w = 12
bullet_h = 40



player_img = os.path.join(player_folder,"spaceship.png")
playership1 = os.path.join(player_folder,"Ship_01.png")
playership2 = os.path.join(player_folder,"Ship_02.png")
playership3 = os.path.join(player_folder,"Ship_03.png")
playership4 = os.path.join(player_folder,"Ship_04.png")
playership5 = os.path.join(player_folder,"Ship_05.png")
playership6 = os.path.join(player_folder,"Ship_06.png")
playership7 = os.path.join(player_folder,"Ship_LVL_2.png")
playership8 = os.path.join(player_folder,"Ship_LVL_3.png")
playership9 = os.path.join(player_folder,"Ship_LVL_4.png")
playership10 = os.path.join(player_folder,"Ship_LVL_5.png")

playerShips = [playership1,playership2,playership3,playership4,playership5,playership6,playership7,playership8,playership9,playership10]

player_bullet = os.path.join(ammo_folder,"Fire_Shot_4_2.png")

fast_Fire = os.path.join(powerups_folder,"Hero_Speed_Debuff.png")


# Enemy Settings
meteors = []

for i in range(10):
    meteors.append(os.path.join(enemy_folder,"Meteor_"+str(i+1)+".png"))

print(meteors)








